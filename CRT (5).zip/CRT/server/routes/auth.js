import express from "express";
import bcrypt from "bcryptjs";
import { query } from "../db.js";
import { issueOtp, consumeOtp } from "../otp.js";
import { createSession, setSessionCookie, clearSessionCookie, getUserFromRequest, destroySession } from "../auth-middleware.js";
import { notify } from "../notify.js";

const router = express.Router();

function emailValid(s) {
  return typeof s === "string" && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s.trim());
}
function usernameValid(s) {
  return typeof s === "string" && /^[a-z0-9_]{3,24}$/.test(s);
}
function passwordValid(s) {
  return typeof s === "string" && s.length >= 8 && s.length <= 128 && /[A-Za-z]/.test(s) && /\d/.test(s);
}

async function hashPassword(plain) {
  return bcrypt.hash(plain, 10);
}

router.post("/request-otp", async (req, res) => {
  try {
    const email = String(req.body.email || "").toLowerCase().trim();
    const requested = req.body.purpose === "reset" ? "reset" : null;
    if (!emailValid(email)) return res.status(400).json({ error: "Invalid email" });
    const { rows } = await query(`SELECT id FROM users WHERE email=$1`, [email]);
    let purpose;
    if (requested === "reset") {
      if (!rows[0]) return res.status(404).json({ error: "No account with that email" });
      purpose = "reset";
    } else {
      // signup verification path only — login uses password
      if (rows[0]) return res.status(409).json({ error: "Email already registered. Use Sign in or Forgot password." });
      purpose = "register";
    }
    const r = await issueOtp(email, purpose);
    res.json({ ok: true, purpose, ttlMinutes: r.ttlMinutes });
  } catch (e) {
    res.status(e.status || 500).json({ error: e.message });
  }
});

router.post("/verify-otp", async (req, res) => {
  try {
    const email = String(req.body.email || "").toLowerCase().trim();
    const code = String(req.body.code || "").trim();
    const requested = req.body.purpose;
    const purpose = requested === "reset" ? "reset" : "register";
    if (!emailValid(email) || !/^\d{6}$/.test(code)) {
      return res.status(400).json({ error: "Invalid email or code" });
    }
    const ok = await consumeOtp(email, code, purpose);
    if (!ok) return res.status(401).json({ error: "Code is incorrect or expired" });
    res.json({ ok: true, verified: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

router.post("/login", async (req, res) => {
  try {
    const email = String(req.body.email || "").toLowerCase().trim();
    const password = String(req.body.password || "");
    if (!emailValid(email) || !password) {
      return res.status(400).json({ error: "Email and password required" });
    }
    const { rows } = await query(
      `SELECT id, role, password_hash FROM users WHERE email=$1`,
      [email]
    );
    const user = rows[0];
    if (!user || !user.password_hash) {
      return res.status(401).json({ error: "Invalid email or password" });
    }
    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok) return res.status(401).json({ error: "Invalid email or password" });

    if (user.role === "doctor") {
      const { rows: dr } = await query(
        `SELECT status FROM doctor_profiles WHERE user_id=$1`,
        [user.id]
      );
      if (!dr[0] || dr[0].status !== "approved") {
        return res.status(403).json({ error: "Doctor account pending admin approval" });
      }
    }
    await query(`UPDATE users SET last_login=NOW() WHERE id=$1`, [user.id]);
    const sess = await createSession(user.id);
    setSessionCookie(res, sess.token, sess.expires);
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

router.post("/reset-password", async (req, res) => {
  try {
    const email = String(req.body.email || "").toLowerCase().trim();
    const code = String(req.body.code || "").trim();
    const password = String(req.body.password || "");
    if (!emailValid(email) || !/^\d{6}$/.test(code)) {
      return res.status(400).json({ error: "Invalid email or code" });
    }
    if (!passwordValid(password)) {
      return res.status(400).json({ error: "Password must be at least 8 characters and include a letter and a number" });
    }
    const ok = await consumeOtp(email, code, "reset");
    if (!ok) return res.status(401).json({ error: "Code is incorrect or expired" });

    const { rows } = await query(`SELECT id FROM users WHERE email=$1`, [email]);
    if (!rows[0]) return res.status(404).json({ error: "Account not found" });
    const hash = await hashPassword(password);
    await query(`UPDATE users SET password_hash=$1 WHERE id=$2`, [hash, rows[0].id]);
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

router.post("/register-student", async (req, res) => {
  try {
    const email = String(req.body.email || "").toLowerCase().trim();
    const username = String(req.body.username || "").toLowerCase().trim();
    const fullName = String(req.body.fullName || "").trim();
    const yearOfStudy = String(req.body.yearOfStudy || "").trim();
    const country = String(req.body.country || "").trim();
    const password = String(req.body.password || "");
    if (!emailValid(email)) return res.status(400).json({ error: "Invalid email" });
    if (!usernameValid(username)) return res.status(400).json({ error: "Username must be 3-24 chars (a-z, 0-9, _)" });
    if (fullName.length < 2) return res.status(400).json({ error: "Name required" });
    if (!passwordValid(password)) return res.status(400).json({ error: "Password must be at least 8 characters and include a letter and a number" });

    const { rows: dup } = await query(`SELECT 1 FROM users WHERE email=$1 OR username=$2`, [email, username]);
    if (dup[0]) return res.status(409).json({ error: "Email or username already in use" });

    const passwordHash = await hashPassword(password);
    const { rows } = await query(
      `INSERT INTO users (email, username, full_name, role, country, password_hash)
       VALUES ($1,$2,$3,'student',$4,$5) RETURNING id`,
      [email, username, fullName, country, passwordHash]
    );
    await query(
      `INSERT INTO student_profiles (user_id, year_of_study) VALUES ($1,$2)`,
      [rows[0].id, yearOfStudy]
    );
    await notify(rows[0].id, "welcome", "Welcome to Reasonal", "Start with the practice loop. One case, one question, one sharp evaluation.", "/practice");
    const sess = await createSession(rows[0].id);
    setSessionCookie(res, sess.token, sess.expires);
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

router.post("/register-doctor", async (req, res) => {
  try {
    const email = String(req.body.email || "").toLowerCase().trim();
    const username = String(req.body.username || "").toLowerCase().trim();
    const fullName = String(req.body.fullName || "").trim();
    const country = String(req.body.country || "").trim();
    const degree = String(req.body.degree || "").trim();
    const specialty = String(req.body.specialty || "").trim();
    const yearsExp = parseInt(req.body.yearsExp, 10) || 0;
    const licenseNumber = String(req.body.licenseNumber || "").trim();
    const hospital = String(req.body.hospital || "").trim();
    const proofText = String(req.body.proofText || "").trim();
    const password = String(req.body.password || "");

    if (!emailValid(email)) return res.status(400).json({ error: "Invalid email" });
    if (!usernameValid(username)) return res.status(400).json({ error: "Invalid username" });
    if (!fullName || !specialty || !licenseNumber) {
      return res.status(400).json({ error: "Name, specialty, and license required" });
    }
    if (!passwordValid(password)) return res.status(400).json({ error: "Password must be at least 8 characters and include a letter and a number" });

    const { rows: dup } = await query(`SELECT 1 FROM users WHERE email=$1 OR username=$2`, [email, username]);
    if (dup[0]) return res.status(409).json({ error: "Email or username already in use" });

    const passwordHash = await hashPassword(password);
    const { rows } = await query(
      `INSERT INTO users (email, username, full_name, role, country, password_hash) VALUES ($1,$2,$3,'doctor',$4,$5) RETURNING id`,
      [email, username, fullName, country, passwordHash]
    );
    await query(
      `INSERT INTO doctor_profiles (user_id, degree, specialty, years_exp, license_number, hospital, proof_text, status)
       VALUES ($1,$2,$3,$4,$5,$6,$7,'pending')`,
      [rows[0].id, degree, specialty, yearsExp, licenseNumber, hospital, proofText]
    );
    const { rows: admins } = await query(`SELECT id FROM users WHERE role='admin'`);
    for (const a of admins) {
      await notify(a.id, "doctor_pending", "New doctor application", `${fullName} (${specialty}) is pending review.`, "/admin");
    }
    res.json({ ok: true, status: "pending" });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

router.get("/me", async (req, res) => {
  const user = await getUserFromRequest(req);
  if (!user) return res.json({ user: null });
  let extra = {};
  if (user.role === "doctor") {
    const { rows } = await query(`SELECT status, specialty, years_exp, hospital FROM doctor_profiles WHERE user_id=$1`, [user.id]);
    extra = rows[0] || {};
  } else if (user.role === "student") {
    const { rows } = await query(`SELECT year_of_study, global_level, specialty_levels, show_scores FROM student_profiles WHERE user_id=$1`, [user.id]);
    extra = rows[0] || {};
  }
  res.json({ user: { ...user, ...extra } });
});

router.post("/logout", async (req, res) => {
  await destroySession(req);
  clearSessionCookie(res);
  res.json({ ok: true });
});

export default router;
