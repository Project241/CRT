import { useEffect, useMemo, useState } from "react";
import { Link } from "wouter";
import {
  FileText, Stethoscope, FolderOpen, Inbox, BarChart3, Users,
  Eye, Edit3, Trash2, MessageSquare, User as UserIcon,
} from "lucide-react";
import AppShell from "../components/AppShell.jsx";
import Modal from "../components/Modal.jsx";
import Pagination from "../components/Pagination.jsx";
import Skeleton, { SkeletonRows } from "../components/Skeleton.jsx";
import EmptyState from "../components/EmptyState.jsx";
import ErrorState from "../components/ErrorState.jsx";
import { useConfirm } from "../components/ConfirmDialog.jsx";
import EditInsteadModal from "../components/EditInsteadModal.jsx";
import useUrlPaging from "../lib/usePaging.js";
import { dateTime, relativeTime } from "../lib/date.js";
import { api } from "../lib/api.js";
import { useToast } from "../components/Toast.jsx";

const PAGE_SIZE = 10;

// Used in place of "—" while stats are loading so the row doesn't look broken.
function StatValue({ value }) {
  if (value === null || value === undefined) {
    return <Skeleton width="60%" height={26} />;
  }
  return <span>{value}</span>;
}

export default function AdminDashboard() {
  const toast = useToast();
  const [confirmEl, askConfirm] = useConfirm();
  const [stats, setStats] = useState(null);
  const [statsError, setStatsError] = useState(null);

  // Pending doctors — URL-synced via ?pPage=
  const [pending, setPending] = useState({ items: [], total: 0, totalPages: 1, loading: true, error: null });
  const pendingPg = useUrlPaging({ initialPage: 1, initialPageSize: PAGE_SIZE, prefix: "p" });
  const pendingPage = pendingPg.page;
  const setPendingPage = pendingPg.setPage;
  const [pendingQ, setPendingQ] = useState("");

  // Delete requests — URL-synced via ?dPage=
  const [drs, setDrs] = useState({ items: [], total: 0, totalPages: 1, loading: true, error: null });
  const drPg = useUrlPaging({ initialPage: 1, initialPageSize: PAGE_SIZE, prefix: "d" });
  const drPage = drPg.page;
  const setDrPage = drPg.setPage;
  const [drQ, setDrQ] = useState("");
  const [drStatus, setDrStatus] = useState("open");

  // Reports — URL-synced via ?rPage=
  const [reports, setReports] = useState({ items: [], total: 0, totalPages: 1, loading: true, error: null });
  const repPg = useUrlPaging({ initialPage: 1, initialPageSize: PAGE_SIZE, prefix: "r" });
  const repPage = repPg.page;
  const setRepPage = repPg.setPage;
  const [repQ, setRepQ] = useState("");
  const [repStatus, setRepStatus] = useState("open");

  // Practice activity
  const [caseAttempts, setCaseAttempts] = useState([]);
  const [studentAttempts, setStudentAttempts] = useState([]);
  const [attemptsSort, setAttemptsSort] = useState("most");
  const [activityLoading, setActivityLoading] = useState(true);
  const [activityError, setActivityError] = useState(null);
  const caseAttemptsPg = useUrlPaging({ initialPage: 1, initialPageSize: 25, prefix: "ca", enabled: false });
  const studentAttemptsPg = useUrlPaging({ initialPage: 1, initialPageSize: 25, prefix: "ua", enabled: false });

  // AI generate
  const [genCount, setGenCount] = useState(5);
  const [genLevel, setGenLevel] = useState(3);
  const [genSpecialty, setGenSpecialty] = useState("");
  const [specialtyList, setSpecialtyList] = useState([]);
  const [genBusy, setGenBusy] = useState(false);

  // Server logs badge
  const [unseenLogs, setUnseenLogs] = useState({ count: 0, hasError: false });

  // Modals
  const [doctorModal, setDoctorModal] = useState(null); // { doctor, action: 'approve'|'reject' }
  const [editInsteadModal, setEditInsteadModal] = useState(null); // { request, case }
  const [reportNoteModal, setReportNoteModal] = useState(null); // { report, status }

  function loadStats() {
    setStats(null);
    setStatsError(null);
    api.get("/api/admin/stats").then(setStats).catch((e) => { setStats({}); setStatsError(e?.message || "Could not load stats"); });
  }

  function loadPending(page = pendingPage, q = pendingQ) {
    setPending((p) => ({ ...p, loading: true, error: null }));
    const params = new URLSearchParams({ page, pageSize: PAGE_SIZE });
    if (q.trim()) params.set("q", q.trim());
    api.get(`/api/admin/doctors/pending?${params}`)
      .then((r) => setPending({
        items: r.items || r.doctors || [],
        total: r.total || 0,
        totalPages: r.totalPages || 1,
        loading: false,
        error: null,
      }))
      .catch((e) => setPending({ items: [], total: 0, totalPages: 1, loading: false, error: e?.message || "Could not load doctor approvals" }));
  }

  function loadDrs(page = drPage, q = drQ, status = drStatus) {
    setDrs((p) => ({ ...p, loading: true, error: null }));
    const params = new URLSearchParams({ page, pageSize: PAGE_SIZE, status });
    if (q.trim()) params.set("q", q.trim());
    api.get(`/api/discussions/delete-requests?${params}`)
      .then((r) => setDrs({
        items: r.items || r.requests || [],
        total: r.total || 0,
        totalPages: r.totalPages || 1,
        loading: false,
        error: null,
      }))
      .catch((e) => setDrs({ items: [], total: 0, totalPages: 1, loading: false, error: e?.message || "Could not load delete requests" }));
  }

  function loadReports(page = repPage, q = repQ, status = repStatus) {
    setReports((p) => ({ ...p, loading: true, error: null }));
    const params = new URLSearchParams({ page, pageSize: PAGE_SIZE, status });
    if (q.trim()) params.set("q", q.trim());
    api.get(`/api/admin/reports?${params}`)
      .then((r) => setReports({
        items: r.items || r.reports || [],
        total: r.total || 0,
        totalPages: r.totalPages || 1,
        loading: false,
        error: null,
      }))
      .catch((e) => setReports({ items: [], total: 0, totalPages: 1, loading: false, error: e?.message || "Could not load reports" }));
  }

  function loadActivity() {
    setActivityLoading(true);
    setActivityError(null);
    Promise.all([
      api.get(`/api/admin/case-attempts?limit=200&sort=${attemptsSort === "least" ? "least" : "most"}`),
      api.get("/api/admin/student-attempts?limit=200"),
    ]).then(([ca, sa]) => {
      setCaseAttempts(ca.cases || []);
      setStudentAttempts(sa.users || []);
      setActivityLoading(false);
    }).catch((e) => {
      setActivityError(e?.message || "Could not load practice activity");
      setActivityLoading(false);
    });
  }

  // Initial load
  useEffect(() => {
    loadStats();
    api.get("/api/cases/specialties")
      .then((r) => setSpecialtyList(r.specialties || []))
      .catch((e) => console.warn("Specialty list fetch failed:", e?.message || e));
  }, []);

  // Pending: refetch on page or search change (debounced for q).
  useEffect(() => {
    const t = setTimeout(() => loadPending(pendingPage, pendingQ), 250);
    return () => clearTimeout(t);
    // eslint-disable-next-line
  }, [pendingPage, pendingQ]);

  // Delete requests
  useEffect(() => {
    const t = setTimeout(() => loadDrs(drPage, drQ, drStatus), 250);
    return () => clearTimeout(t);
    // eslint-disable-next-line
  }, [drPage, drQ, drStatus]);

  // Reports
  useEffect(() => {
    const t = setTimeout(() => loadReports(repPage, repQ, repStatus), 250);
    return () => clearTimeout(t);
    // eslint-disable-next-line
  }, [repPage, repQ, repStatus]);

  // Activity
  useEffect(() => { loadActivity(); /* eslint-disable-next-line */ }, [attemptsSort]);

  // Server-logs badge listener
  useEffect(() => {
    function onStatus(e) {
      const d = e.detail || {};
      setUnseenLogs({ count: d.count || 0, hasError: !!d.hasError });
    }
    window.addEventListener("admin:logs:status", onStatus);
    return () => window.removeEventListener("admin:logs:status", onStatus);
  }, []);

  async function generateCases() {
    setGenBusy(true);
    try {
      const r = await api.post("/api/admin/cases/generate", {
        count: genCount,
        level: genLevel,
        specialty: genSpecialty || null,
      });
      const okN = r.inserted?.length || 0;
      if (okN === 0) toast.error("AI generation failed — check server logs");
      else if (r.failedCount) toast.success(`Generated ${okN} of ${genCount} cases (${r.failedCount} failed)`);
      else toast.success(`Generated ${okN} cases with diagnoses`);
      loadStats();
    } catch (e) { toast.error(e.message); }
    finally { setGenBusy(false); }
  }

  // ----- Doctor approve / reject (modal) -----
  function openDoctorModal(doctor, action) {
    setDoctorModal({ doctor, action, note: "" });
  }
  async function submitDoctorDecision() {
    const { doctor, action, note } = doctorModal;
    if (action === "reject" && !note.trim()) {
      toast.error("Please provide a reason for rejecting this applicant.");
      return;
    }
    try {
      await api.patch(`/api/admin/doctors/${doctor.id}/${action}`, { note: note.trim() });
      toast.success(action === "approve" ? "Doctor approved" : "Application rejected");
      setDoctorModal(null);
      loadPending();
      loadStats();
    } catch (e) { toast.error(e.message); }
  }

  // ----- Delete request decisions -----
  async function deleteRequestApprove(request) {
    const ok = await askConfirm({
      title: "Delete this case?",
      body: <>This permanently hides <strong>"{request.case_title}"</strong> from learners. The requester will be notified.</>,
      confirmLabel: "Delete case",
      cancelLabel: "Keep case",
      tone: "danger",
      requireText: "DELETE",
    });
    if (!ok) return;
    try {
      await api.patch(`/api/admin/delete-requests/${request.id}`, { decision: "approved" });
      toast.success("Case deleted");
      loadDrs(); loadStats();
    } catch (e) { toast.error(e.message); }
  }
  async function deleteRequestReject(request) {
    const ok = await askConfirm({
      title: "Reject delete request?",
      body: <>Keep <strong>"{request.case_title}"</strong> in the library. The requester will be notified.</>,
      confirmLabel: "Reject request",
      cancelLabel: "Cancel",
      tone: "primary",
    });
    if (!ok) return;
    try {
      await api.patch(`/api/admin/delete-requests/${request.id}`, { decision: "rejected" });
      toast.success("Request rejected");
      loadDrs(); loadStats();
    } catch (e) { toast.error(e.message); }
  }
  async function openEditInstead(request) {
    setEditInsteadModal({ request });
  }

  // ----- Activity-row direct delete (irreversible — gated by typing DELETE) -----
  async function deleteCaseFromActivity(c) {
    const ok = await askConfirm({
      title: "Delete this case?",
      body: <>This permanently hides <strong>"{c.title || `Case #${c.id}`}"</strong> from learners. Their attempt history is preserved.</>,
      confirmLabel: "Delete case",
      cancelLabel: "Cancel",
      tone: "danger",
      requireText: "DELETE",
    });
    if (!ok) return;
    try {
      await api.del(`/api/admin/cases/${c.id}`);
      toast.success("Case deleted");
      loadActivity(); loadStats();
    } catch (e) { toast.error(e.message); }
  }

  // ----- Reports actions -----
  function openReportAction(report, status) {
    setReportNoteModal({ report, status, note: "" });
  }
  async function submitReportAction() {
    const { report, status, note } = reportNoteModal;
    try {
      await api.patch(`/api/admin/reports/${report.id}`, { status, note: note.trim() });
      toast.success(status === "actioned" ? "Marked as actioned" : status === "dismissed" ? "Report dismissed" : "Report re-opened");
      setReportNoteModal(null);
      loadReports();
    } catch (e) { toast.error(e.message); }
  }

  const pendingDoctorBadge = useMemo(() => stats?.pendingDoctors ?? null, [stats]);

  return (
    <AppShell>
      <div className="container fade-in">
        {/* Header */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12, flexWrap: "wrap" }}>
          <div>
            <h2 style={{ margin: 0 }}>Admin</h2>
            <p className="muted" style={{ marginTop: 4 }}>Approvals, reports, and platform health.</p>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
            <Link href="/admin/logs" className="btn" style={{ position: "relative", display: "inline-flex", alignItems: "center", gap: 6 }}>
              <FileText size={16} strokeWidth={1.75} aria-hidden="true" /> Server logs
              {unseenLogs.count > 0 && (
                <span
                  title={`${unseenLogs.count} new ${unseenLogs.hasError ? "error/warning" : "warning"}${unseenLogs.count > 1 ? "s" : ""}`}
                  style={{
                    position: "absolute", top: -6, right: -6,
                    minWidth: 18, height: 18, padding: "0 5px",
                    borderRadius: 999,
                    background: unseenLogs.hasError ? "#dc2626" : "#d97706",
                    color: "#fff", fontSize: 11, fontWeight: 700, lineHeight: "18px",
                    textAlign: "center", boxShadow: "0 0 0 2px var(--bg, #fff)",
                    animation: "pulseDot 1.6s ease-in-out infinite",
                  }}
                >
                  {unseenLogs.count > 99 ? "99+" : unseenLogs.count}
                </span>
              )}
            </Link>
          </div>
        </div>

        {/* Stats */}
        <div className="spacer-7" />
        <div className="stat-row">
          <div className="stat"><div className="stat-label">Cases</div><div className="stat-value"><StatValue value={stats?.cases} /></div></div>
          <div className="stat"><div className="stat-label">Total attempts</div><div className="stat-value"><StatValue value={stats?.responses} /></div></div>
          <div className="stat"><div className="stat-label">Cases attempted</div><div className="stat-value"><StatValue value={stats?.attemptedCases} /></div></div>
          <div className="stat"><div className="stat-label">Active learners</div><div className="stat-value"><StatValue value={stats?.distinctAttempters} /></div></div>
          <div className="stat"><div className="stat-label">Pending doctors</div><div className="stat-value"><StatValue value={stats?.pendingDoctors} /></div></div>
          <div className="stat"><div className="stat-label">Open delete reqs</div><div className="stat-value"><StatValue value={stats?.openDeleteRequests} /></div></div>
        </div>

        {/* Pending doctors */}
        <div className="spacer-7" />
        <div className="card">
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 8 }}>
            <h3 style={{ margin: 0 }}>
              Doctor approvals
              {pendingDoctorBadge ? <span className="muted small" style={{ marginLeft: 8 }}>({pendingDoctorBadge} pending)</span> : null}
            </h3>
            <input
              className="input"
              placeholder="Search name, email, license, hospital…"
              value={pendingQ}
              onChange={(e) => { setPendingQ(e.target.value); setPendingPage(1); }}
              style={{ maxWidth: 320 }}
            />
          </div>
          <div className="spacer-7" />
          {pending.loading && pending.items.length === 0 ? (
            <SkeletonRows n={4} avatar={false} />
          ) : pending.error ? (
            <ErrorState body={pending.error} onRetry={() => loadPending(pendingPage, pendingQ)} />
          ) : pending.items.length === 0 ? (
            <EmptyState
              icon={<Stethoscope size={24} strokeWidth={1.75} aria-hidden="true" />}
              title={pendingQ ? "No matches" : "Inbox zero"}
              body={pendingQ ? "No applications match your search." : "No pending doctor applications. You're all caught up."}
            />
          ) : (
            <>
              <div style={{ overflowX: "auto" }}>
                <table className="table table-sticky-first">
                  <thead><tr><th>Name</th><th>Specialty</th><th>License</th><th>Hospital</th><th>Proof</th><th></th></tr></thead>
                  <tbody>
                    {pending.items.map((d) => (
                      <tr key={d.id}>
                        <td>
                          <Link href={`/u/${d.username}`}><strong className="clamp-2">{d.full_name}</strong></Link>
                          <div className="muted small">@{d.username} · {d.email}</div>
                        </td>
                        <td>{d.specialty}<div className="muted small">{d.years_exp || 0}y</div></td>
                        <td>{d.license_number}</td>
                        <td>{d.hospital || "—"}</td>
                        <td className="muted small clamp-2" style={{ maxWidth: 280 }}>{d.proof_text || "—"}</td>
                        <td>
                          <div className="row row-actions">
                            <button className="btn btn-primary btn-sm" onClick={() => openDoctorModal(d, "approve")}>Approve</button>
                            <button className="btn btn-danger btn-sm" onClick={() => openDoctorModal(d, "reject")}>Reject</button>
                            <Link href={`/messages/u/${d.username}`} className="btn btn-ghost btn-sm" title="Send a message">DM</Link>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <Pagination page={pendingPage} totalPages={pending.totalPages} total={pending.total} onChange={setPendingPage} />
            </>
          )}
        </div>

        {/* Delete requests */}
        <div className="spacer-7" />
        <div className="card">
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 8 }}>
            <h3 style={{ margin: 0 }}>Delete requests</h3>
            <div className="row" style={{ gap: 8, flexWrap: "wrap" }}>
              <select
                className="select"
                value={drStatus}
                onChange={(e) => { setDrStatus(e.target.value); setDrPage(1); }}
                style={{ width: 160 }}
              >
                <option value="open">Open only</option>
                <option value="approved">Approved</option>
                <option value="rejected">Rejected</option>
                <option value="edit_instead">Edited instead</option>
                <option value="all">All</option>
              </select>
              <input
                className="input"
                placeholder="Search case, requester, reason…"
                value={drQ}
                onChange={(e) => { setDrQ(e.target.value); setDrPage(1); }}
                style={{ maxWidth: 280 }}
              />
            </div>
          </div>
          <div className="spacer-7" />
          {drs.loading && drs.items.length === 0 ? (
            <SkeletonRows n={4} avatar={false} />
          ) : drs.error ? (
            <ErrorState body={drs.error} onRetry={() => loadDrs(drPage, drQ, drStatus)} />
          ) : drs.items.length === 0 ? (
            <EmptyState
              icon={<FolderOpen size={24} strokeWidth={1.75} aria-hidden="true" />}
              title={drQ ? "No matches" : "Nothing to review"}
              body={drQ ? "No requests match your search." : `No ${drStatus === "all" ? "" : drStatus + " "}delete requests.`}
            />
          ) : (
            <>
              <div style={{ overflowX: "auto" }}>
                <table className="table table-sticky-first">
                  <thead><tr><th>Case</th><th>Specialty</th><th>Requester</th><th>Reason</th><th>Status</th><th></th></tr></thead>
                  <tbody>
                    {drs.items.map((d) => (
                      <tr key={d.id}>
                        <td><Link href={`/discussion/${d.case_id}?tab=delete-request&dr=${d.id}`}><strong className="clamp-2">{d.case_title}</strong></Link></td>
                        <td>{d.specialty}</td>
                        <td><Link href={`/u/${d.requester_username}`}>@{d.requester_username}</Link></td>
                        <td className="muted small clamp-2" style={{ maxWidth: 320 }}>{d.reason}</td>
                        <td><span className="muted small">{d.status}</span></td>
                        <td>
                          {d.status === "open" ? (
                            <div className="row row-actions">
                              <button className="btn btn-danger btn-sm" onClick={() => deleteRequestApprove(d)}>Delete</button>
                              <button className="btn btn-secondary btn-sm" onClick={() => openEditInstead(d)}>Edit instead</button>
                              <Link href={`/upload?edit=${d.case_id}`} className="btn btn-ghost btn-sm">Open editor</Link>
                              <button className="btn btn-ghost btn-sm" onClick={() => deleteRequestReject(d)}>Reject</button>
                            </div>
                          ) : (
                            <span className="muted small">resolved</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <Pagination page={drPage} totalPages={drs.totalPages} total={drs.total} onChange={setDrPage} />
            </>
          )}
        </div>

        {/* Reports */}
        <div className="spacer-7" />
        <div className="card">
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 8 }}>
            <h3 style={{ margin: 0 }}>Reports</h3>
            <div className="row" style={{ gap: 8, flexWrap: "wrap" }}>
              <select
                className="select"
                value={repStatus}
                onChange={(e) => { setRepStatus(e.target.value); setRepPage(1); }}
                style={{ width: 160 }}
              >
                <option value="open">Open only</option>
                <option value="actioned">Actioned</option>
                <option value="dismissed">Dismissed</option>
                <option value="all">All</option>
              </select>
              <input
                className="input"
                placeholder="Search case, reporter, reason…"
                value={repQ}
                onChange={(e) => { setRepQ(e.target.value); setRepPage(1); }}
                style={{ maxWidth: 280 }}
              />
            </div>
          </div>
          <div className="spacer-7" />
          {reports.loading && reports.items.length === 0 ? (
            <SkeletonRows n={4} avatar={false} />
          ) : reports.error ? (
            <ErrorState body={reports.error} onRetry={() => loadReports(repPage, repQ, repStatus)} />
          ) : reports.items.length === 0 ? (
            <EmptyState
              icon={<Inbox size={24} strokeWidth={1.75} aria-hidden="true" />}
              title={repQ ? "No matches" : "No reports to review"}
              body={repQ ? "No reports match your search." : `No ${repStatus === "all" ? "" : repStatus + " "}reports right now.`}
            />
          ) : (
            <>
              <div style={{ overflowX: "auto" }}>
                <table className="table table-sticky-first">
                  <thead><tr><th>Case</th><th>By</th><th>Reason</th><th>Status</th><th>When</th><th></th></tr></thead>
                  <tbody>
                    {reports.items.map((r) => (
                      <tr key={r.id}>
                        <td><Link href={`/case/${r.case_id}`}><strong className="clamp-2">{r.title}</strong></Link></td>
                        <td><Link href={`/u/${r.username}`}>@{r.username}</Link></td>
                        <td className="muted small clamp-2" style={{ maxWidth: 320 }}>{r.reason}</td>
                        <td><span className="muted small">{r.status || "open"}</span></td>
                        <td className="muted small" title={r.created_at ? new Date(r.created_at).toLocaleString() : ""}>{relativeTime(r.created_at)}</td>
                        <td>
                          {(r.status || "open") === "open" ? (
                            <div className="row row-actions">
                              <button className="btn btn-primary btn-sm" onClick={() => openReportAction(r, "actioned")}>Mark actioned</button>
                              <button className="btn btn-ghost btn-sm" onClick={() => openReportAction(r, "dismissed")}>Dismiss</button>
                            </div>
                          ) : (
                            <button className="btn btn-ghost btn-sm" onClick={() => openReportAction(r, "open")}>Re-open</button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <Pagination page={repPage} totalPages={reports.totalPages} total={reports.total} onChange={setRepPage} />
            </>
          )}
        </div>

        {/* Practice activity — by case */}
        <div className="spacer-7" />
        <div className="card">
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 8 }}>
            <div>
              <h3 style={{ margin: 0 }}>Practice activity — by case</h3>
              <p className="muted small" style={{ marginTop: 4 }}>How many times each case has been attempted, and by how many distinct learners.</p>
            </div>
            <div className="row" style={{ gap: 6 }}>
              <button className={`btn btn-sm ${attemptsSort === "most" ? "btn-primary" : "btn-ghost"}`} onClick={() => setAttemptsSort("most")}>Most attempted</button>
              <button className={`btn btn-sm ${attemptsSort === "least" ? "btn-primary" : "btn-ghost"}`} onClick={() => setAttemptsSort("least")}>Least attempted</button>
            </div>
          </div>
          <div className="spacer-7" />
          {activityLoading ? (
            <SkeletonRows n={6} avatar={false} />
          ) : activityError ? (
            <ErrorState body={activityError} onRetry={loadActivity} />
          ) : caseAttempts.length === 0 ? (
            <EmptyState
              icon={<BarChart3 size={24} strokeWidth={1.75} aria-hidden="true" />}
              title="No attempts yet"
              body="Once learners start practicing, you'll see usage here."
            />
          ) : (() => {
            const total = caseAttempts.length;
            const pageSize = caseAttemptsPg.pageSize;
            const totalPages = Math.max(1, Math.ceil(total / pageSize));
            const page = Math.min(caseAttemptsPg.page, totalPages);
            const start = (page - 1) * pageSize;
            const slice = caseAttempts.slice(start, start + pageSize);
            return (
              <>
                <div style={{ overflowX: "auto" }}>
                  <table className="table table-sticky-first" style={{ width: "100%", fontSize: 13 }}>
                    <thead>
                      <tr>
                        <th style={{ textAlign: "left" }}>Case</th>
                        <th style={{ textAlign: "left" }}>Specialty</th>
                        <th style={{ textAlign: "center" }}>Lvl</th>
                        <th style={{ textAlign: "right" }}>Attempts</th>
                        <th style={{ textAlign: "right" }}>Unique learners</th>
                        <th style={{ textAlign: "left" }}>Last attempt</th>
                        <th></th>
                      </tr>
                    </thead>
                    <tbody>
                      {slice.map((c) => (
                        <tr key={c.id}>
                          <td>
                            <Link href={`/case/${c.id}`} className="clamp-2">{c.title || `Case #${c.id}`}</Link>
                          </td>
                          <td>{c.specialty || "—"}</td>
                          <td style={{ textAlign: "center" }}>{c.level ?? "—"}</td>
                          <td style={{ textAlign: "right", fontWeight: 700 }}>{c.attempts}</td>
                          <td style={{ textAlign: "right" }}>{c.unique_students}</td>
                          <td className="muted small" title={c.last_attempt ? new Date(c.last_attempt).toLocaleString() : ""}>{relativeTime(c.last_attempt) || "—"}</td>
                          <td>
                            <div className="row row-actions" style={{ justifyContent: "flex-end", gap: 4 }}>
                              <Link
                                href={`/case/${c.id}`}
                                className="icon-action"
                                aria-label={`View case ${c.title || c.id}`}
                                title="View case"
                              >
                                <Eye size={16} strokeWidth={1.75} aria-hidden="true" />
                              </Link>
                              <Link
                                href={`/upload?edit=${c.id}`}
                                className="icon-action"
                                aria-label={`Edit case ${c.title || c.id}`}
                                title="Edit case"
                              >
                                <Edit3 size={16} strokeWidth={1.75} aria-hidden="true" />
                              </Link>
                              <button
                                type="button"
                                className="icon-action is-danger"
                                aria-label={`Delete case ${c.title || c.id}`}
                                title="Delete case"
                                onClick={() => deleteCaseFromActivity(c)}
                              >
                                <Trash2 size={16} strokeWidth={1.75} aria-hidden="true" />
                              </button>
                              <Link
                                href={`/discussion/${c.id}`}
                                className="icon-action"
                                aria-label={`Open discussion for ${c.title || c.id}`}
                                title="Open discussion"
                              >
                                <MessageSquare size={16} strokeWidth={1.75} aria-hidden="true" />
                              </Link>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <Pagination
                  page={page}
                  totalPages={totalPages}
                  total={total}
                  pageSize={pageSize}
                  onChange={caseAttemptsPg.setPage}
                  onPageSizeChange={caseAttemptsPg.setPageSize}
                />
              </>
            );
          })()}
        </div>

        {/* Practice activity — by learner */}
        <div className="spacer-7" />
        <div className="card">
          <h3 style={{ margin: 0 }}>Practice activity — by learner</h3>
          <p className="muted small" style={{ marginTop: 4 }}>Who is practicing the most. Includes both students and doctors.</p>
          <div className="spacer-7" />
          {activityLoading ? (
            <SkeletonRows n={6} avatar />
          ) : activityError ? (
            <ErrorState body={activityError} onRetry={loadActivity} />
          ) : studentAttempts.length === 0 ? (
            <EmptyState
              icon={<Users size={24} strokeWidth={1.75} aria-hidden="true" />}
              title="No learners active"
              body="Once people start practicing, you'll see them here."
            />
          ) : (() => {
            const total = studentAttempts.length;
            const pageSize = studentAttemptsPg.pageSize;
            const totalPages = Math.max(1, Math.ceil(total / pageSize));
            const page = Math.min(studentAttemptsPg.page, totalPages);
            const start = (page - 1) * pageSize;
            const slice = studentAttempts.slice(start, start + pageSize);
            return (
              <>
                <div style={{ overflowX: "auto" }}>
                  <table className="table table-sticky-first" style={{ width: "100%", fontSize: 13 }}>
                    <thead>
                      <tr>
                        <th style={{ textAlign: "left" }}>User</th>
                        <th style={{ textAlign: "left" }}>Role</th>
                        <th style={{ textAlign: "right" }}>Total attempts</th>
                        <th style={{ textAlign: "right" }}>Unique cases</th>
                        <th style={{ textAlign: "left" }}>Last attempt</th>
                        <th></th>
                      </tr>
                    </thead>
                    <tbody>
                      {slice.map((u) => (
                        <tr key={u.id}>
                          <td>
                            <Link href={`/u/${u.username}`} className="clamp-2">{u.full_name || u.username}</Link>
                          </td>
                          <td>{u.role}</td>
                          <td style={{ textAlign: "right", fontWeight: 700 }}>{u.attempts}</td>
                          <td style={{ textAlign: "right" }}>{u.unique_cases}</td>
                          <td className="muted small" title={u.last_attempt ? new Date(u.last_attempt).toLocaleString() : ""}>{relativeTime(u.last_attempt) || "—"}</td>
                          <td>
                            <div className="row row-actions" style={{ justifyContent: "flex-end", gap: 4 }}>
                              <Link
                                href={`/u/${u.username}`}
                                className="icon-action"
                                aria-label={`View profile of @${u.username}`}
                                title="View profile"
                              >
                                <UserIcon size={16} strokeWidth={1.75} aria-hidden="true" />
                              </Link>
                              <Link
                                href={`/messages/u/${u.username}`}
                                className="icon-action"
                                aria-label={`Open DM with @${u.username}`}
                                title="Open DM"
                              >
                                <MessageSquare size={16} strokeWidth={1.75} aria-hidden="true" />
                              </Link>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <Pagination
                  page={page}
                  totalPages={totalPages}
                  total={total}
                  pageSize={pageSize}
                  onChange={studentAttemptsPg.setPage}
                  onPageSizeChange={studentAttemptsPg.setPageSize}
                />
              </>
            );
          })()}
        </div>

        {/* AI generate (moved to bottom) */}
        <div className="spacer-7" />
        <div className="card">
          <h3>Generate cases with AI</h3>
          <p className="muted small" style={{ marginTop: 4 }}>
            Generates clinical cases with diagnoses and accepted-answer aliases. Cases are tagged as AI-generated. Review and verify before relying on them clinically.
          </p>
          <div className="spacer-7" />
          <div className="row" style={{ gap: 10, alignItems: "flex-end", flexWrap: "wrap" }}>
            <div className="field" style={{ minWidth: 140 }}>
              <label className="label">How many?</label>
              <select className="select" value={genCount} onChange={(e) => setGenCount(parseInt(e.target.value, 10))} disabled={genBusy}>
                <option value={1}>1 case</option>
                <option value={3}>3 cases</option>
                <option value={5}>5 cases</option>
                <option value={10}>10 cases</option>
              </select>
            </div>
            <div className="field" style={{ minWidth: 180 }}>
              <label className="label">Level (difficulty)</label>
              <select className="select" value={genLevel} onChange={(e) => setGenLevel(parseInt(e.target.value, 10))} disabled={genBusy}>
                <option value={1}>Level 1 — easiest (1st year)</option>
                <option value={2}>Level 2 — 2nd year</option>
                <option value={3}>Level 3 — 3rd year</option>
                <option value={4}>Level 4 — 4th year</option>
                <option value={5}>Level 5 — intern</option>
                <option value={6}>Level 6 — resident</option>
                <option value={7}>Level 7 — hardest (advanced resident)</option>
              </select>
            </div>
            <div className="field" style={{ minWidth: 220 }}>
              <label className="label">Specialty</label>
              <select className="select" value={genSpecialty} onChange={(e) => setGenSpecialty(e.target.value)} disabled={genBusy}>
                <option value="">Mixed (random per case)</option>
                {specialtyList.map((s) => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
            <button className="btn btn-primary" onClick={generateCases} disabled={genBusy} style={{ height: 40 }}>
              {genBusy ? <><span className="spinner" /> Generating… (may take 30–90s)</> : `Generate ${genCount} case${genCount === 1 ? "" : "s"}`}
            </button>
          </div>
        </div>
      </div>

      {/* ----- Doctor approve / reject modal ----- */}
      <Modal
        open={!!doctorModal}
        onClose={() => setDoctorModal(null)}
        title={doctorModal?.action === "approve" ? "Approve doctor" : "Reject doctor"}
      >
        {doctorModal && (
          <div>
            <p className="muted small" style={{ marginTop: 0 }}>
              {doctorModal.action === "approve"
                ? `Approving ${doctorModal.doctor.full_name}. They will be able to log in and verify cases.`
                : `Rejecting ${doctorModal.doctor.full_name}. They will be notified with the reason below.`}
            </p>
            <label className="label">
              {doctorModal.action === "reject" ? "Reason (required)" : "Note to applicant (optional)"}
            </label>
            <textarea
              className="input"
              rows={4}
              value={doctorModal.note}
              onChange={(e) => setDoctorModal({ ...doctorModal, note: e.target.value })}
              placeholder={doctorModal.action === "reject"
                ? "Explain why this application is being rejected…"
                : "Optional welcome message or onboarding note…"}
              style={{ width: "100%", resize: "vertical" }}
              autoFocus
            />
            <div className="row" style={{ justifyContent: "flex-end", gap: 8, marginTop: 16 }}>
              <button className="btn btn-ghost" onClick={() => setDoctorModal(null)}>Cancel</button>
              <button
                className={doctorModal.action === "approve" ? "btn btn-primary" : "btn btn-danger"}
                onClick={submitDoctorDecision}
              >
                {doctorModal.action === "approve" ? "Approve" : "Reject"}
              </button>
            </div>
          </div>
        )}
      </Modal>

      {/* ----- Edit-instead modal ----- */}
      <EditInsteadModal
        open={!!editInsteadModal}
        request={editInsteadModal?.request}
        onClose={() => setEditInsteadModal(null)}
        onResolved={() => { loadDrs(); loadStats(); }}
      />


      {/* ----- Report action modal ----- */}
      <Modal
        open={!!reportNoteModal}
        onClose={() => setReportNoteModal(null)}
        title={
          reportNoteModal?.status === "actioned" ? "Mark report as actioned" :
          reportNoteModal?.status === "dismissed" ? "Dismiss report" :
          "Re-open report"
        }
      >
        {reportNoteModal && (
          <div>
            <p className="muted small" style={{ marginTop: 0 }}>
              <strong>Report:</strong> {reportNoteModal.report.title || "Untitled case"}
              <br />
              <em>{reportNoteModal.report.reason}</em>
            </p>
            <label className="label">Note (optional, for internal records)</label>
            <textarea
              className="input"
              rows={3}
              value={reportNoteModal.note}
              onChange={(e) => setReportNoteModal({ ...reportNoteModal, note: e.target.value })}
              placeholder="What did you do? e.g. 'Edited the case to remove the inaccurate dose.'"
              style={{ width: "100%", resize: "vertical" }}
              autoFocus
            />
            <div className="row" style={{ justifyContent: "flex-end", gap: 8, marginTop: 16 }}>
              <button className="btn btn-ghost" onClick={() => setReportNoteModal(null)}>Cancel</button>
              <button className="btn btn-primary" onClick={submitReportAction}>Save</button>
            </div>
          </div>
        )}
      </Modal>

      {confirmEl}
    </AppShell>
  );
}
